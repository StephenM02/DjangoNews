from django.shortcuts import render
from newsapi import NewsApiClient

# Create your views here.


def Index(request) :
    newsapi = NewsApiClient()